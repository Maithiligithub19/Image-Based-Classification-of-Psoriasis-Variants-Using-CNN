from PIL import Image
import os

# Path to the dataset directory
dataset_dir = 'dataset'

# Iterate through all subdirectories in the dataset directory
for subdir, dirs, files in os.walk(dataset_dir):
    for file in files:
        # Construct the full path to the file
        file_path = os.path.join(subdir, file)
        
        # Check if the file is an image (skip if not)
        if file_path.lower().endswith(('.png', '.jpg', '.jpeg', '.tiff', '.bmp', '.gif')):
            try:
                # Open the image
                with Image.open(file_path) as img:
                    # Convert the image to RGB mode in case it's not
                    img = img.convert('RGB')
                    
                    # Create a new file path for the JPEG version
                    # This replaces the original extension with .jpg
                    new_file_path = os.path.splitext(file_path)[0] + '.jpg'
                    
                    # Save the image in JPEG format
                    img.save(new_file_path, 'JPEG')
                    
                    # If you want to remove the original file (be careful with this)
                    os.remove(file_path)
                    
                    print(f"Converted {file_path} to {new_file_path}")
            except Exception as e:
                print(f"Error converting {file_path}: {e}")
