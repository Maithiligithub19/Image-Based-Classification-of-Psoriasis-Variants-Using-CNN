from flask import Flask, render_template, request, redirect, url_for, session
import tensorflow as tf
import numpy as np
import os

app = Flask(__name__)

app.secret_key = 'psoriasis'

app.jinja_env.auto_reload = True
app.config['TEMPLATES_AUTO_RELOAD'] = True
app.config['UPLOAD_FOLDER'] = 'static/uploads'

# Update this line to specify the correct path to your .h5 file
loaded_model = tf.keras.models.load_model('cnn_model.h5')

class_names = ['Erythrodermic', 'Guttate', 'Inverse', 'Nail', 'Normal', 'Plaque', 'Pustular']

def preprocess_image(image_path, img_height=224, img_width=224):
    img = tf.io.read_file(image_path)
    img = tf.image.decode_image(img, channels=3)
    img = tf.image.resize(img, [img_height, img_width])
    img /= 255.0  # Normalize to [0,1] range
    img = tf.expand_dims(img, 0)  # Add batch dimension
    return img

def predict_image_class(loaded_model, image_path):
    img = preprocess_image(image_path)
    predictions = loaded_model.predict(img)
    predicted_class = np.argmax(predictions, axis=1)[0]  # Get the index of the max probability
    confidence = np.max(tf.nn.softmax(predictions, axis=1)[0])  # Get the max probability as confidence
    return class_names[predicted_class], confidence

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        f = request.files['image']
        if f and '.' in f.filename and f.filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS:
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], f.filename)
            f.save(file_path)
            predicted_class, confidence = predict_image_class(loaded_model, file_path)
            # Adjusted to pass both predicted class and confidence to the template
            return render_template('index.html', file_path=file_path, file_result=predicted_class, confidence=confidence)
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)