import os
import numpy as np
from PIL import Image
import imgaug as ia
import imgaug.augmenters as iaa
import numpy as np

# Define your augmentation sequence
seq = iaa.Sequential([
    iaa.Fliplr(0.5),  # horizontal flips with a 50% probability
    iaa.Crop(percent=(0, 0.1)),  # random crops
    iaa.Sometimes(0.5, iaa.GaussianBlur(sigma=(0, 0.5))),  # gaussian blur
    iaa.LinearContrast((0.75, 1.5)),  # contrast changes
    iaa.AdditiveGaussianNoise(loc=0, scale=(0.0, 0.05*255), per_channel=0.5),  # gaussian noise
    iaa.Multiply((0.8, 1.2), per_channel=0.2),  # brightness changes
    iaa.Affine(
        scale={"x": (0.8, 1.2), "y": (0.8, 1.2)},
        translate_percent={"x": (-0.2, 0.2), "y": (-0.2, 0.2)},
        rotate=(-25, 25),
        shear=(-8, 8)
    )  # affine transformations
], random_order=True)  # apply augmenters in random order

def augment_images_in_folder(folder_path):
    for subdir, dirs, files in os.walk(folder_path):
        for file in files:
            if file.lower().endswith(('.jpg', '.jpeg')):
                image_path = os.path.join(subdir, file)
                image = Image.open(image_path)
                image = ia.imresize_single_image(np.array(image), (224, 224))  # Resize image
                image_aug = seq(image=np.array(image))  # Apply augmentation
                image_aug = Image.fromarray(image_aug).convert('RGB')  # Convert to RGB
                image_aug.save(os.path.join(subdir, f"aug_{file}"))  # Save augmented image

# Path to your dataset folder
dataset_folder_path = 'dataset'
augment_images_in_folder(dataset_folder_path)
