import os
import random
import string

def generate_random_name(length=10):
    """Generate a random name of specified length."""
    letters = string.ascii_lowercase
    return ''.join(random.choice(letters) for _ in range(length))

def rename_files(directory):
    """Rename all files in the given directory."""
    for root, dirs, files in os.walk(directory):
        for filename in files:
            # Generate a random name
            random_name = generate_random_name()
            
            # Get the file extension
            _, extension = os.path.splitext(filename)
            
            # Generate the new filename
            new_filename = random_name + extension
            
            # Full path of the original file
            old_filepath = os.path.join(root, filename)
            
            # Full path of the new file
            new_filepath = os.path.join(root, new_filename)
            
            # Rename the file
            os.rename(old_filepath, new_filepath)
            print(f"Renamed {filename} to {new_filename}")

# Replace 'dataset' with the path to your dataset folder
dataset_folder = 'dataset'

# Call the function to rename files in the dataset folder
rename_files(dataset_folder)
